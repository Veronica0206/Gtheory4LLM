# Sparse conditional-mode solve and first-order Laplace evaluation.
#
# This is the dense solver's control flow carried out in sparse storage, at a
# fixed parameter vector. It is deliberately a line-for-line twin of
# .gt_d_dense_mode() rather than a second algorithm that reaches a similar
# answer: Newton step, line search, descent condition, acceptance test,
# iteration budget, final-mode recomputation and the relaxed final tolerance
# all stay in their original order, because the dense file records that order
# as a requirement and the frozen reference was produced by it.
#
# Only seven operations differ, and each is a call into the sparse algebra that
# earlier steps already established:
#
#   dense                                sparse
#   W %*% u                              sparse product, same W convention
#   crossprod(W, gradient)               sparse crossprod
#   .gt_d_dense_hessian(...)             .gt_d_sparse_hessian(...)
#   chol(H)                              .gt_d_sparse_factor(H)
#   backsolve(R, forwardsolve(t(R), g))  .gt_d_sparse_solve(factor, g)
#   sum(log(diag(R)))                    .gt_d_sparse_logdet(factor) / 2
#   .gt_d_final_factor_check(H, R)       .gt_d_sparse_final_factor_check(H, factor)
#
# The solve-validity check after the Newton step is the SAME function on both
# sides, .gt_d_solve_check(), applied to the sparse H without densifying it;
# only the final-factor probe solve differs, because it goes through the
# factor object rather than a triangular matrix. The invariant, the bound and
# the refusal are otherwise identical, so a sparse fit is refused at exactly
# the points a dense fit would be refused.
#
# The last line is the one to read twice. The dense value adds the log
# determinant of the Cholesky factor, which is half the log determinant of the
# Hessian; .gt_d_sparse_logdet() returns the whole one. Carrying the sparse
# value across unhalved would double the Laplace correction while leaving the
# mode, the gradient and every Hessian entry in exact agreement, so no test of
# the conditional problem would notice. The halving is asserted separately
# against the reference's own Laplace identity rather than left to this
# comment.
#
# Everything outside those six operations is shared code, not copied code: the
# likelihood, gradient and curvature all come from .gt_d_response_kernel(),
# which no backend touches.
#
# Binary and ordinal responses are the supported envelope, as in the Hessian
# assembly. Categorical blocks are refused here too, before any work is done,
# so the refusal names the dense backend instead of surfacing from underneath.

.gt_d_sparse_mode <- function(parameters, prep, backend, control, details = FALSE) {
  if (!inherits(backend, "gt_discrete_sparse_backend") ||
      !identical(c(backend$n, backend$q), c(prep$n, prep$q)))
    .gt_d_stop("Sparse mode inputs do not match the prepared response dimensions.")
  W <- backend$W
  if (!methods::is(W, "sparseMatrix") || nrow(W) != prep$n * prep$q || ncol(W) < 1L)
    .gt_d_stop("Invalid matrix supplied to the sparse mode solver.")
  stored <- tryCatch(methods::slot(W, "x"), error = function(e) NULL)
  if (!is.null(stored) && any(!is.finite(stored)))
    .gt_d_stop("Invalid matrix supplied to the sparse mode solver.")
  if (!is.numeric(parameters) || length(parameters) < length(prep$start) ||
      !is.list(control) || !is.numeric(control$inner_maxit) || length(control$inner_maxit) != 1L ||
      !is.finite(control$inner_maxit) || control$inner_maxit < 1 ||
      control$inner_maxit != floor(control$inner_maxit) ||
      !is.numeric(control$inner_tol) || length(control$inner_tol) != 1L ||
      !is.finite(control$inner_tol) || control$inner_tol <= 0)
    .gt_d_stop("Invalid parameters or controls supplied to the sparse mode solver.")
  families <- vapply(prep$blocks, `[[`, character(1), "family")
  if (any(families == "categorical"))
    .gt_d_stop("The sparse mode solver takes binary and ordinal responses; ",
               "the dense backend takes categorical ones.")
  baseline <- .gt_d_baseline(parameters, prep)
  u <- numeric(ncol(W))
  converged <- FALSE
  accepted <- TRUE
  last_gradient <- Inf
  for (iter in seq_len(control$inner_maxit)) {
    eta <- baseline + matrix(as.numeric(W %*% u), prep$n, prep$q)
    response <- .gt_d_response_kernel(eta, parameters, prep)
    if (!response$valid) return(if (details) list(valid = FALSE, inner_iterations = iter) else 1e100)
    gradient <- as.numeric(Matrix::crossprod(W, response$gradient)) + u
    last_gradient <- max(abs(gradient))
    if (last_gradient <= control$inner_tol) { converged <- TRUE; break }
    H <- .gt_d_sparse_hessian(response$curvature, W, prep$n)
    # tryCatch, not a bare call: the dense solver treats a Hessian with no
    # Cholesky factor as an invalid evaluation and returns, and .gt_d_sparse_factor()
    # signals that condition by stopping. Letting the stop escape would turn a
    # value the dense path reports into an error the sparse path raises.
    factorization <- tryCatch(.gt_d_sparse_factor(H), error = function(e) NULL)
    if (is.null(factorization)) return(if (details) list(valid = FALSE) else 1e100)
    step <- .gt_d_sparse_solve(factorization, gradient)
    # The same invariant, at the same point, as the dense solver: checked
    # immediately after the solve and before the line search consumes the
    # step. A sparse Cholesky can likewise return without error and still hand
    # back a factor of some other matrix (issue #14), and a violated invariant
    # makes the sparse conditional solve unavailable, with no rescue. The
    # backward error is taken against the sparse H directly, so nothing here
    # densifies the matrix.
    solve_check <- .gt_d_solve_check(H, gradient, step)
    if (!isTRUE(solve_check$valid))
      return(if (details) c(list(valid = FALSE, reason = "sparse_newton_solve_invalid"),
                            solve_check[.GT_D_SOLVE_DETAIL],
                            # The failed operation itself, for a specimen file.
                            # Built only on failure; never retained in a fit.
                            list(inner_iterations = iter,
                                 specimen = list(hessian = H, right_hand_side = gradient,
                                                 step = step, factor = factorization$factor))) else 1e100)
    objective <- response$nll + sum(u^2) / 2
    descent <- sum(gradient * step)
    multiplier <- 1
    accepted <- FALSE
    for (line in seq_len(30L)) {
      candidate <- u - multiplier * step
      next_eta <- baseline + matrix(as.numeric(W %*% candidate), prep$n, prep$q)
      next_response <- .gt_d_response_kernel(next_eta, parameters, prep)
      if (next_response$valid && next_response$nll + sum(candidate^2) / 2 <=
          objective - 1e-4 * multiplier * descent + 1e-12) {
        u <- as.vector(candidate)
        accepted <- TRUE
        break
      }
      multiplier <- multiplier / 2
    }
    if (!accepted) break
  }
  # Always recompute at the final mode, including when max iterations was hit.
  eta <- baseline + matrix(as.numeric(W %*% u), prep$n, prep$q)
  response <- .gt_d_response_kernel(eta, parameters, prep)
  if (!response$valid) return(if (details) list(valid = FALSE, inner_iterations = iter) else 1e100)
  last_gradient <- max(abs(as.numeric(Matrix::crossprod(W, response$gradient)) + u))
  converged <- is.finite(last_gradient) && last_gradient <= control$inner_tol * 10
  H <- .gt_d_sparse_hessian(response$curvature, W, prep$n)
  factorization <- tryCatch(.gt_d_sparse_factor(H), error = function(e) NULL)
  # As in the dense solver: how a non-converged solve stopped is recorded.
  if (is.null(factorization) || !converged) return(if (details)
    list(valid = FALSE, inner_converged = converged, inner_gradient = last_gradient,
         inner_iterations = iter, inner_line_search_failed = !accepted,
         inner_factor_unavailable = is.null(factorization)) else 1e100)
  # The final factor feeds a log determinant rather than a solve, so the Newton
  # check above does not cover it. Validated with the same fixed probes the
  # dense solver uses, through the factor object's own permutation-aware solve,
  # before its diagonal contributes to the Laplace objective.
  factor_check <- .gt_d_sparse_final_factor_check(H, factorization)
  if (!isTRUE(factor_check$valid)) return(if (details)
    c(list(valid = FALSE, reason = "sparse_final_factor_invalid",
           inner_converged = converged, inner_gradient = last_gradient,
           inner_iterations = iter),
      factor_check[c(.GT_D_SOLVE_DETAIL, "probe_index")],
      list(specimen = list(hessian = H, factor = factorization$factor))) else 1e100)
  # Half the log determinant, matching sum(log(diag(R))) in the dense solver.
  value <- response$nll + sum(u^2) / 2 + .gt_d_sparse_logdet(factorization) / 2
  if (!details) return(value)
  list(valid = TRUE, nll = value, mode = u, eta = eta,
       conditional_nll = response$nll, inner_iterations = iter,
       inner_converged = converged, inner_gradient = last_gradient,
       random_dimension = length(u))
}

# The sparse marginal evaluator, shaped to be substituted for .gt_d_laplace().
#
# Same signature, same return shape, same meaning. Everything outside the
# marginal evaluation stays with the caller: preparation, parameterization,
# bounds, starts, the optimizer, restarts, tight validation, stationarity and
# acceptance are the dense implementation's and are not duplicated here.
#
# Only the inner numerical path differs:
#
#   decode covariance factors   (shared)
#   build sparse W              (from retained geometry)
#   response kernel             (shared, backend-independent)
#   sparse conditional mode     (.gt_d_sparse_mode)
#   half the sparse log det     (.gt_d_sparse_logdet)
#
# The coordinate geometry is retained across calls because an outer optimizer
# evaluates this many times and the design does not change between them. The
# sparsity pattern is not retained; see .gt_d_sparse_context().
#
# There is no fallback. If the sparse path cannot evaluate, this returns what
# the dense path returns for an unevaluable point, and the caller's existing
# acceptance rules decide. A backend that quietly handed a failed evaluation to
# another implementation would make a rejection depend on which engine ran.
.gt_d_sparse_evaluator <- function() {
  context <- NULL
  function(parameters, prep, groups, setup, control, details = FALSE,
           factors_override = NULL) {
    if (is.null(context)) {
      context <<- .gt_d_sparse_context(groups, prep$n, prep$q)
    } else if (!identical(context$groups, groups) ||
               !identical(context$n, as.integer(prep$n)) ||
               !identical(context$q, as.integer(prep$q))) {
      # The retained geometry belongs to one design. Reusing it for another
      # would silently evaluate a different model.
      #
      # Compare the grouping itself, not its dimensions. Two designs can agree
      # on observation count, latent dimension, source count and every level
      # count while disagreeing on which observation belongs to which level,
      # and that difference is exactly what the retained geometry encodes. A
      # dimension-only check admits such a design and answers with the cached
      # coordinates: a finite, plausible value computed for a model that was
      # not asked about. identical() on the groups covers source order and
      # names, level counts, and every observation's index.
      .gt_d_stop("The sparse evaluator was reused across different designs.")
    }
    fixed_length <- length(prep$start)
    factors <- if (is.null(factors_override))
      .gt_d_covariance_factors(parameters[-seq_len(fixed_length)], setup) else factors_override
    backend <- .gt_d_sparse_backend_from(context, factors)
    answer <- .gt_d_sparse_mode(parameters, prep, backend, control, details)
    if (details && isTRUE(answer$valid))
      answer <- append(answer, list(factors = factors), after = 2L)
    answer
  }
}
