# Documentation policy: man/*.Rd and NAMESPACE are hand written and are
# the only source of truth. These comments describe the code for readers;
# they are deliberately not roxygen, so running roxygen2 cannot replace the
# richer Rd pages or drop the S3 methods registered in NAMESPACE.
# Analytic observed Gaussian and identified latent binary/ordinal coefficients.

# Declare explicit weights for a composite on an already specified score scale
gt_score <- function(weights) {
  if (!is.numeric(weights) || !length(weights) || any(!is.finite(weights)) ||
      is.null(names(weights)) || anyNA(names(weights)) || any(!nzchar(names(weights))) ||
      anyDuplicated(names(weights)) || !any(weights != 0))
    stop("weights must be a finite, uniquely named vector with at least one nonzero entry.", call. = FALSE)
  structure(list(weights = weights, normalization = "as_supplied"), class = "gt_score")
}

# Panel facts for the balanced-panel rules, from the data where it was kept.
.gt_reliability_panel <- function(fit, dimensions) {
  if (is.data.frame(fit$data)) {
    counts <- stats::setNames(vapply(fit$data[dimensions],
      function(x) length(unique(x)), integer(1)), dimensions)
    return(list(counts = counts, rows = nrow(fit$data),
      cell_replication = as.integer(table(.gt_tuple_key(fit$data, dimensions)))))
  }
  panel <- fit$panel
  if (!is.list(panel) || !identical(panel$dimensions, dimensions))
    stop("This fit retains neither its modelled data nor a matching panel summary, so a balanced-panel coefficient cannot be checked. Refit with gt_control(retain = list(data = TRUE)).", call. = FALSE)
  list(counts = panel$counts, rows = panel$rows,
       cell_replication = panel$cell_replication)
}

.gt_reliability_context <- function(fit, scale) {
  if (!inherits(fit, "gt_fit")) stop("Expected a gt_fit object.", call. = FALSE)
  if (!.gt_fit_usable(fit))
    stop("Reliability and D studies require a numerically converged fit. Inspect gt_diagnostics(fit) and resolve the fitting failure first.", call. = FALSE)
  types <- vapply(fit$families, `[[`, character(1), "family")
  gaussian <- all(types == "gaussian")
  if (is.null(scale)) {
    if (!gaussian) stop("For binary/ordinal fits, explicitly request scale='latent'; observed-score coefficients need a separate integration method.", call. = FALSE)
    scale <- "observed"
  }
  if (!is.character(scale) || length(scale) != 1L || is.na(scale)) stop("Specify one coefficient scale.", call. = FALSE)
  if (any(types == "categorical"))
    stop("Unordered categorical outcomes have no default scalar G/Phi. Define a substantive score or category-probability estimand before computing reliability; this is not implemented yet.", call. = FALSE)
  if ((gaussian && scale != "observed") || (!gaussian && scale != "latent"))
    stop("This implementation supports observed Gaussian coefficients and identified latent binary/ordinal coefficients only.", call. = FALSE)
  # Check the retained data when it is present, so a panel edited after fitting
  # is still caught. When the caller asked not to keep it, fall back to the
  # summary recorded at fitting time and apply exactly the same two rules.
  dimensions <- c(fit$design$object, fit$design$facets)
  panel <- .gt_reliability_panel(fit, dimensions)
  if (panel$rows != prod(panel$counts) * fit$design$replicates)
    stop("Analytic coefficients currently require a complete balanced coded panel; unbalanced allocations need separate D-study integration.", call. = FALSE)
  if (any(panel$cell_replication != fit$design$replicates))
    stop("Analytic coefficients require the declared equal within-cell replication.", call. = FALSE)
  counts <- panel$counts
  components <- fit$covariance_components
  if (!gaussian) {
    latent_variance <- vapply(fit$families, function(f)
      if (f$link == "probit") 1 else pi^2 / 3, numeric(1))
    components$Residual <- diag(latent_variance, nrow = length(latent_variance))
    dimnames(components$Residual) <- list(fit$outcomes, fit$outcomes)
  }
  # A call effect is shared by the items of one call and by no others, so its
  # part in relative error depends on which items share calls. The weights
  # below know nothing of that and would count it as error common to every
  # item. The separate batch-aware API requires explicit fixed-layout targets.
  if (identical(.gt_batch_status(fit$design)$status, "modelled"))
    stop("This fit models a call effect. Use gt_batch_reliability() or gt_batch_dstudy() ",
         "for explicit targets conditional on its fixed batching layout. The ordinary ",
         "gt_reliability()/gt_dstudy() coefficients do not account for shared calls.", call. = FALSE)
  expected <- c(fit$design$terms, "Residual")
  if (!all(expected %in% names(components))) stop("Missing fitted covariance components.", call. = FALSE)
  if (any(vapply(components[expected], function(x)
    !is.matrix(x) || !identical(dim(x), c(length(fit$outcomes), length(fit$outcomes))) ||
      any(!is.finite(x)), logical(1))))
    stop("Source covariance dimensions do not match the outcome dimensions.", call. = FALSE)
  list(components = components, counts = counts[fit$design$facets], scale = scale,
       gaussian = gaussian, replicates = fit$design$replicates,
       uncertainty = .gt_coefficient_uncertainty_source(fit, gaussian))
}

# Only a fitted Gaussian source covariance carries a usable curvature-based
# covariance matrix. A latent discrete scale additionally holds its residual
# variance fixed by the link, which is not an estimated quantity at all.
.gt_coefficient_uncertainty_source <- function(fit, gaussian) {
  unavailable <- function(reason) list(available = FALSE, reason = reason,
    entries = NULL, entry_covariance = NULL, method = NA_character_,
    boundary_components = character(), restricted_to_interior = FALSE,
    fixed_components = character(), fixed_component_kinds = character())
  if (!gaussian)
    return(unavailable("Standard errors are not implemented for the discrete Laplace engine; its coefficients are point estimates only."))
  record <- fit$uncertainty
  if (!is.list(record) || !isTRUE(record$available))
    return(unavailable(if (is.list(record) && length(record$reason) && !is.na(record$reason))
      record$reason else "No parameter covariance matrix is available for this fit."))
  if (is.null(record$entries) || is.null(record$entry_covariance))
    return(unavailable("The fit does not carry a source-covariance delta-method mapping."))
  list(available = TRUE, reason = NA_character_, entries = record$entries,
       entry_covariance = record$entry_covariance, method = record$method,
       boundary_components = record$boundary_components,
       restricted_to_interior = isTRUE(record$restricted_to_interior),
       fixed_components = record$fixed_components,
       fixed_component_kinds = record$fixed_component_kinds)
}

.gt_reliability_fixed <- function(fit, fixed, counts, observed) {
  if (is.null(fixed)) fixed <- character()
  if (!is.character(fixed) || anyNA(fixed) || any(!nzchar(fixed)) || anyDuplicated(fixed))
    stop("fixed must be a character vector of unique, nonempty instrumentation facet names.", call. = FALSE)
  if (!length(fixed)) return(character())
  unknown <- setdiff(fixed, fit$design$facets)
  if (length(unknown))
    stop("fixed must name declared instrumentation facets; unknown facet(s): ",
         paste(unknown, collapse = ", "), ".", call. = FALSE)
  if (setequal(fixed, fit$design$facets))
    stop("At least one facet must remain random. With every facet fixed there is no facet-sampling error to generalize over, and this design provides no estimable error variance.", call. = FALSE)
  mismatched <- fixed[counts[fixed] != observed[fixed]]
  if (length(mismatched))
    stop("A fixed facet's universe is exactly its observed levels, so its count cannot be changed: ",
         paste(paste0(mismatched, " (observed ", observed[mismatched], ", requested ",
                      counts[mismatched], ")"), collapse = ", "), ".", call. = FALSE)
  fit$design$facets[fit$design$facets %in% fixed]
}

# Brennan (2001) mixed-model decomposition. With every facet random this
# reduces exactly to the fully random weights. For a fixed facet h:
# object-by-fixed terms are averaged over its n_h levels and enter the
# universe score; terms with no object and no random facet shift every object
# equally and leave the model; every other term keeps its usual divisor.
.gt_reliability_weights <- function(fit, counts, replicates, fixed) {
  object <- fit$design$object
  terms <- fit$design$terms
  members <- fit$design$term_members
  labels <- c(terms, "Residual")
  zero <- stats::setNames(numeric(length(labels)), labels)
  universe <- relative <- absolute <- zero
  roles <- stats::setNames(rep("unused", length(labels)), labels)
  universe[[object]] <- 1
  roles[[object]] <- "universe"
  residual_divisor <- prod(counts) * replicates
  relative[["Residual"]] <- absolute[["Residual"]] <- 1 / residual_divisor
  roles[["Residual"]] <- "relative_and_absolute_error"
  for (term in setdiff(terms, object)) {
    facets_in <- setdiff(members[[term]], object)
    divisor <- prod(counts[facets_in])
    random_in <- setdiff(facets_in, fixed)
    if (object %in% members[[term]]) {
      if (length(random_in)) {
        relative[[term]] <- absolute[[term]] <- 1 / divisor
        roles[[term]] <- "relative_and_absolute_error"
      } else {
        universe[[term]] <- 1 / divisor
        roles[[term]] <- "universe_after_fixed_facet_averaging"
      }
    } else if (length(random_in)) {
      absolute[[term]] <- 1 / divisor
      roles[[term]] <- "absolute_error"
    } else {
      roles[[term]] <- "dropped_fixed_instrumentation_constant"
    }
  }
  list(universe = universe, relative = relative, absolute = absolute, roles = roles)
}

# Compute G and Phi under a declared balanced score design
# scale: observed for Gaussian; explicitly latent for binary/ordinal.
# score: Optional gt_score object; per-trait results are always returned.
# design: Optional named positive integer instrumentation counts.
#   Retained as an alias for counts for compatibility.
# counts: Optional named positive integer instrumentation counts.
# fixed: Instrumentation facets treated as fixed rather than randomly
#   sampled. Defaults to none, reproducing the fully random model.
# level: Confidence level for the reported coefficient intervals.
gt_reliability <- function(fit, scale = NULL, score = NULL, design = NULL,
                           counts = NULL, fixed = character(), level = 0.95) {
  if (!is.null(design) && !is.null(counts))
    stop("Supply counts or its compatibility alias design, not both.", call. = FALSE)
  if (!is.null(counts)) design <- counts
  .gt_check_level(level)
  context <- .gt_reliability_context(fit, scale)
  counts <- context$counts
  if (!is.null(design)) {
    if (!is.numeric(design) || is.null(names(design)) || anyNA(names(design)) ||
        anyDuplicated(names(design)) || any(!names(design) %in% names(counts)) ||
        any(!is.finite(design)) || any(design < 1 | design != floor(design)))
      stop("design must contain named positive integer counts of declared instrumentation facets.", call. = FALSE)
    counts[names(design)] <- design
  }
  fixed <- .gt_reliability_fixed(fit, fixed, counts, context$counts)
  .gt_reliability_kernel(fit, context, counts, score, fixed, level)
}

.gt_check_level <- function(level) {
  if (!is.numeric(level) || length(level) != 1L || is.na(level) || !is.finite(level) ||
      level <= 0 || level >= 1)
    stop("level must be one number strictly between 0 and 1.", call. = FALSE)
  invisible(level)
}

# Derivative of a ratio of nonnegative variance aggregates, mapped onto the
# unique source covariance entries the fit's parameter covariance describes.
# Returns NA rather than a number whenever the curvature record is missing.
.gt_coefficient_standard_error <- function(context, fit, weight, universe_weights,
                                           error_weights, universe, error) {
  record <- context$uncertainty
  total <- universe + error
  if (!isTRUE(record$available) || !is.finite(total) || total <= 0) return(NA_real_)
  entries <- record$entries
  row_position <- match(entries$row, fit$outcomes)
  column_position <- match(entries$column, fit$outcomes)
  if (anyNA(row_position) || anyNA(column_position)) return(NA_real_)
  sources <- names(universe_weights)
  if (any(!entries$component %in% sources)) return(NA_real_)
  per_source <- (universe_weights[entries$component] * error -
                 universe * error_weights[entries$component]) / total^2
  multiplier <- ifelse(row_position == column_position, 1, 2)
  gradient <- as.numeric(per_source) * weight[row_position] * weight[column_position] * multiplier
  variance <- drop(crossprod(gradient, record$entry_covariance %*% gradient))
  if (!is.finite(variance) || variance < 0) return(NA_real_)
  sqrt(variance)
}

# Wald interval on the logit scale so a coefficient interval stays inside the
# (0, 1) range the coefficient itself occupies. A point estimate exactly at a
# boundary has no such interval and is reported as NA, not as 0 or 1.
.gt_coefficient_interval <- function(value, standard_error, level) {
  z <- stats::qnorm(1 - (1 - level) / 2)
  lower <- upper <- rep(NA_real_, length(value))
  usable <- is.finite(value) & is.finite(standard_error) & standard_error > 0 &
    value > 0 & value < 1
  if (any(usable)) {
    eta <- log(value[usable] / (1 - value[usable]))
    spread <- z * standard_error[usable] / (value[usable] * (1 - value[usable]))
    lower[usable] <- stats::plogis(eta - spread)
    upper[usable] <- stats::plogis(eta + spread)
  }
  list(lower = lower, upper = upper)
}

# Context is validated once per D study, independently of grid size.
.gt_reliability_kernel <- function(fit, context, counts, score, fixed = character(),
                                   level = 0.95) {
  matrices <- context$components
  weights <- .gt_reliability_weights(fit, counts, context$replicates, fixed)
  combine <- function(w) Reduce(`+`, Map(function(a, M) a * M, w, matrices[names(w)]))
  universe <- combine(weights$universe)
  relative <- combine(weights$relative)
  absolute <- combine(weights$absolute)
  ratio <- function(u, e) ifelse(is.finite(u + e) & u + e > 0, u / (u + e), NA_real_)
  coefficient <- function(weight, error_matrix, error_weights) {
    u <- as.numeric(crossprod(weight, universe %*% weight))
    e <- as.numeric(crossprod(weight, error_matrix %*% weight))
    value <- ratio(u, e)
    standard_error <- .gt_coefficient_standard_error(context, fit, weight,
      weights$universe, error_weights, u, e)
    interval <- .gt_coefficient_interval(value, standard_error, level)
    c(value = value, se = standard_error, lower = interval$lower, upper = interval$upper)
  }
  unit <- function(j) {
    w <- numeric(length(fit$outcomes))
    w[[j]] <- 1
    w
  }
  relative_rows <- vapply(seq_along(fit$outcomes),
    function(j) coefficient(unit(j), relative, weights$relative), numeric(4L))
  absolute_rows <- vapply(seq_along(fit$outcomes),
    function(j) coefficient(unit(j), absolute, weights$absolute), numeric(4L))
  per_trait <- data.frame(outcome = fit$outcomes,
    Erho2 = relative_rows["value", ], Erho2_se = relative_rows["se", ],
    Erho2_lower = relative_rows["lower", ], Erho2_upper = relative_rows["upper", ],
    Phi = absolute_rows["value", ], Phi_se = absolute_rows["se", ],
    Phi_lower = absolute_rows["lower", ], Phi_upper = absolute_rows["upper", ],
    stringsAsFactors = FALSE)
  composite <- NULL
  if (!is.null(score)) {
    if (!inherits(score, "gt_score") || !setequal(names(score$weights), fit$outcomes))
      stop("score must explicitly weight every outcome exactly once.", call. = FALSE)
    w <- as.numeric(score$weights[fit$outcomes])
    relative_composite <- coefficient(w, relative, weights$relative)
    absolute_composite <- coefficient(w, absolute, weights$absolute)
    composite <- data.frame(
      Erho2 = relative_composite[["value"]], Erho2_se = relative_composite[["se"]],
      Erho2_lower = relative_composite[["lower"]], Erho2_upper = relative_composite[["upper"]],
      Phi = absolute_composite[["value"]], Phi_se = absolute_composite[["se"]],
      Phi_lower = absolute_composite[["lower"]], Phi_upper = absolute_composite[["upper"]],
      row.names = NULL)
  }
  rownames(per_trait) <- NULL
  structure(list(per_trait = per_trait, composite = composite,
       universe_covariance = universe, relative_error_covariance = relative,
       absolute_error_covariance = absolute, scale = context$scale, score = score,
       design = counts, replicates = context$replicates, fixed_facets = fixed,
       random_facets = setdiff(names(counts), fixed),
       source_roles = weights$roles, source_weights = weights[c("universe", "relative", "absolute")],
       level = level, uncertainty = context$uncertainty,
       extrapolated = any(counts > context$counts),
       model = if (length(fixed)) "mixed (Brennan 2001): object-by-fixed-facet variance enters the universe score" else
         "fully random facets",
       interpretation = if (context$gaussian) "Gaussian observed-score coefficient" else
         "Identified latent-response coefficient; not reliability of binary proportions or ordinal observed scores",
       batch = .gt_batch_status(fit$design),
       fit_diagnostics = gt_diagnostics(fit)), class = "gt_reliability")
}

# Evaluate balanced allocations using the analytic coefficient definitions
gt_dstudy <- function(fit, grid, scale = NULL, score = NULL, fixed = character(),
                      level = 0.95) {
  .gt_check_level(level)
  context <- .gt_reliability_context(fit, scale)
  if (!is.data.frame(grid) || !nrow(grid) || !ncol(grid) || anyDuplicated(names(grid)) ||
      any(!names(grid) %in% names(context$counts)) ||
      !all(vapply(grid, is.numeric, logical(1))))
    stop("grid must be a nonempty numeric data frame of declared instrumentation facet counts.", call. = FALSE)
  values <- as.matrix(grid)
  if (any(!is.finite(values)) || any(values < 1 | values != floor(values)))
    stop("D-study counts must be positive finite integers.", call. = FALSE)
  allocation <- as.data.frame(as.list(context$counts), check.names = FALSE)[rep(1L, nrow(grid)), , drop = FALSE]
  rownames(allocation) <- NULL
  allocation[names(grid)] <- grid
  fixed <- .gt_reliability_fixed(fit, fixed, context$counts, context$counts)
  varied <- intersect(names(grid), fixed)
  if (length(varied))
    stop("A decision study cannot project over a fixed facet's population; remove ",
         paste(varied, collapse = ", "), " from grid or from fixed.", call. = FALSE)
  result <- lapply(seq_len(nrow(grid)), function(i) {
    co <- .gt_reliability_kernel(fit, context,
      unlist(allocation[i, , drop = FALSE], use.names = TRUE), score, fixed, level)
    table <- data.frame(design_id = i, kind = "outcome", co$per_trait, stringsAsFactors = FALSE)
    if (!is.null(co$composite)) table <- rbind(table,
      data.frame(design_id = i, kind = "composite", outcome = "composite", co$composite))
    table
  })
  results <- do.call(rbind, result)
  rownames(results) <- NULL
  structure(list(allocations = allocation, results = results,
                 scale = context$scale, score = score, level = level,
                 fixed_facets = fixed, uncertainty = context$uncertainty,
                 measurements_per_object = apply(allocation, 1L, prod) * context$replicates,
                 extrapolated = apply(allocation, 1L, function(x) any(x > context$counts)),
                 batch = .gt_batch_status(fit$design),
                 fit_diagnostics = gt_diagnostics(fit)), class = "gt_dstudy")
}

# Join by the recorded design identity, not by coefficient-row position: a
# multivariate study has several result rows for each allocation.
.gt_reporting_table <- function(results, allocations, measurements, extrapolated,
                                x, row.names = NULL) {
  ids <- results$design_id
  if (!is.numeric(ids) || anyNA(ids) || any(!is.finite(ids)) ||
      any(ids != floor(ids)))
    stop("Result design_id values must identify allocation rows.", call. = FALSE)
  position <- match(ids, seq_len(nrow(allocations)))
  if (anyNA(position))
    stop("Result design_id values must identify allocation rows.", call. = FALSE)
  if (length(measurements) != nrow(allocations) || length(extrapolated) != nrow(allocations))
    stop("Allocation metadata does not match the allocation rows.", call. = FALSE)
  allocation_columns <- make.unique(paste0("allocation_", names(allocations)), sep = "_")
  # Prefixes keep facets such as 'outcome', 'kind', and 'Phi' from replacing
  # coefficient fields. Keep exact original labels in an explicit mapping.
  for (j in seq_along(allocations))
    results[[allocation_columns[j]]] <- allocations[[j]][position]
  record <- x$uncertainty
  reason <- if (length(record$reason)) as.character(record$reason)[1L] else NA_character_
  conditional <- isTRUE(record$restricted_to_interior)
  conditioning <- if (conditional && length(record$fixed_components))
    .gt_conditioning_clause(record$fixed_components, record$fixed_component_kinds) else NA_character_
  results$scale <- rep(x$scale, nrow(results))
  results$interval_level <- rep(x$level, nrow(results))
  results$uncertainty_available <- rep(isTRUE(record$available), nrow(results))
  results$uncertainty_reason <- rep(reason, nrow(results))
  results$uncertainty_conditional <- rep(conditional, nrow(results))
  results$uncertainty_conditioning <- rep(conditioning, nrow(results))
  for (coefficient in c("Erho2", "Phi"))
    results[[paste0(coefficient, "_interval_available")]] <-
      is.finite(results[[coefficient]]) & is.finite(results[[paste0(coefficient, "_lower")]]) &
      is.finite(results[[paste0(coefficient, "_upper")]])
  results$fixed_facets <- rep(paste(encodeString(x$fixed_facets, quote = '"'),
                                    collapse = "; "), nrow(results))
  weights <- if (!is.null(x$score)) paste(
    paste0(encodeString(names(x$score$weights), quote = '"'), " = ",
           format(x$score$weights, digits = 17L, trim = TRUE)), collapse = "; ") else NA_character_
  results$composite_weights <- ifelse(results$kind == "composite", weights, NA_character_)
  results$measurements_per_object <- measurements[position]
  results$measurement_count_exact <- is.finite(results$measurements_per_object) &
    results$measurements_per_object < 2^53
  results$extrapolated <- extrapolated[position]
  # A column, not only an attribute: a CSV keeps the one and drops the other.
  batch <- .gt_batch_status_of(x)
  results$batch_status <- rep(batch$status, nrow(results))
  rownames(results) <- row.names
  attr(results, "allocation_columns") <- stats::setNames(names(allocations), allocation_columns)
  attr(results, "fixed_facets") <- x$fixed_facets
  attr(results, "score") <- x$score
  attr(results, "batch") <- batch
  attr(results, "uncertainty") <- record[intersect(names(record),
    c("available", "reason", "method", "boundary_components", "restricted_to_interior",
      "fixed_components", "fixed_component_kinds"))]
  attr(results, "interpretation") <- paste("Conditional projections from fitted source covariances;",
    "intervals describe estimation uncertainty, not future-panel prediction or accuracy.")
  results
}

as.data.frame.gt_reliability <- function(x, row.names = NULL, optional = FALSE, ...) {
  if (!inherits(x, "gt_reliability")) stop("Expected a gt_reliability object.", call. = FALSE)
  results <- data.frame(design_id = 1L, kind = "outcome", x$per_trait,
                        stringsAsFactors = FALSE, check.names = FALSE)
  if (!is.null(x$composite)) results <- rbind(results,
    data.frame(design_id = 1L, kind = "composite", outcome = "composite", x$composite,
               stringsAsFactors = FALSE, check.names = FALSE))
  allocations <- as.data.frame(as.list(x$design), check.names = FALSE)
  .gt_reporting_table(results, allocations, prod(x$design) * x$replicates,
                       x$extrapolated, x, row.names)
}

as.data.frame.gt_dstudy <- function(x, row.names = NULL, optional = FALSE, ...) {
  if (!inherits(x, "gt_dstudy")) stop("Expected a gt_dstudy object.", call. = FALSE)
  .gt_reporting_table(x$results, x$allocations, x$measurements_per_object,
                       x$extrapolated, x, row.names)
}

.gt_check_coefficient <- function(coefficient) {
  if (!is.character(coefficient) || length(coefficient) != 1L || is.na(coefficient) ||
      !coefficient %in% c("Erho2", "Phi"))
    stop("coefficient must be one of \"Erho2\" or \"Phi\".", call. = FALSE)
}

.gt_check_target <- function(target) {
  if (!is.numeric(target) || length(target) != 1L || is.na(target) ||
      !is.finite(target) || target < 0 || target > 1)
    stop("target must be one finite number from 0 to 1.", call. = FALSE)
}

.gt_reporting_select <- function(table, outcome, kind, single = FALSE) {
  if (!is.null(kind) && (!is.character(kind) || length(kind) != 1L || is.na(kind) ||
                        !kind %in% c("outcome", "composite")))
    stop("kind must be \"outcome\" or \"composite\".", call. = FALSE)
  if (!is.null(outcome) && (!is.character(outcome) || length(outcome) != 1L ||
                           is.na(outcome) || !nzchar(outcome)))
    stop("outcome must name one reported outcome.", call. = FALSE)
  if (!is.null(kind)) table <- table[table$kind == kind, , drop = FALSE]
  if (!is.null(outcome)) table <- table[table$outcome == outcome, , drop = FALSE]
  if (!nrow(table)) stop("No results match the requested outcome and kind.", call. = FALSE)
  if (single && length(unique(table$outcome)) > 1L)
    stop("Specify outcome explicitly when more than one outcome is reported.", call. = FALSE)
  if (!is.null(outcome) && is.null(kind) && length(unique(table$kind)) > 1L)
    stop("This outcome label occurs in more than one kind; specify kind explicitly.", call. = FALSE)
  table
}

# Screen only supplied candidates using their point projections. Unknown
# coefficients stay unknown, and every qualifying minimum-count tie survives.
gt_dstudy_target <- function(x, target, coefficient = "Erho2", outcome = NULL,
                             kind = "outcome") {
  if (!inherits(x, "gt_dstudy")) stop("Expected a gt_dstudy object.", call. = FALSE)
  .gt_check_target(target)
  .gt_check_coefficient(coefficient)
  if (is.null(kind)) stop("kind must be \"outcome\" or \"composite\".", call. = FALSE)
  table <- .gt_reporting_select(as.data.frame(x), outcome, kind, single = TRUE)
  table$coefficient <- rep(coefficient, nrow(table))
  table$target <- rep(target, nrow(table))
  table$estimate <- table[[coefficient]]
  table$meets_target <- ifelse(is.finite(table$estimate), table$estimate >= target, NA)
  table$fewest_measurements <- ifelse(is.na(table$meets_target), NA, FALSE)
  qualified <- which(table$meets_target)
  exact <- qualified[table$measurement_count_exact[qualified]]
  # Beyond the exact-integer range, distinct allocations can round to an
  # apparent tie. Any eligible exact small count beats these large totals;
  # otherwise their ordering is unknown without exact integer arithmetic.
  if (length(exact)) table$fewest_measurements[exact] <-
    table$measurements_per_object[exact] == min(table$measurements_per_object[exact])
  else table$fewest_measurements[qualified] <- NA
  attr(table, "target_context") <- list(coefficient = coefficient, target = target,
    outcome = unique(table$outcome), kind = kind, scale = x$scale,
    comparison = "point_estimate", scope = "supplied_candidates_only",
    batch_status = .gt_batch_status_of(x)$status,
    note = paste("Fewest measurements among supplied candidates with a known point projection",
      "meeting the target; ties retained. This is not a global optimum, a cost optimum,",
      "or a guarantee that a future panel reaches the target."))
  rownames(table) <- NULL
  table
}

.gt_print_coefficient_options <- function(digits, max_rows) {
  if (!is.numeric(digits) || length(digits) != 1L || is.na(digits) ||
      !is.finite(digits) || digits < 1 || digits > 22 || digits != floor(digits))
    stop("digits must be one integer from 1 to 22.", call. = FALSE)
  if (!is.numeric(max_rows) || length(max_rows) != 1L || is.na(max_rows) ||
      !is.finite(max_rows) || max_rows < 1 || max_rows != floor(max_rows))
    stop("max_rows must be one positive integer.", call. = FALSE)
}

# Hide interval columns that carry no information for this fit rather than
# printing a block of NA that reads as a computed result.
.gt_drop_empty_columns <- function(table) {
  keep <- vapply(table, function(column) !is.numeric(column) || any(is.finite(column)), logical(1))
  table[, keep, drop = FALSE]
}

.gt_print_uncertainty_note <- function(x) {
  record <- x$uncertainty
  if (!is.list(record)) return(invisible(NULL))
  if (isTRUE(record$available)) {
    cat(format(100 * x$level, digits = 4), "% intervals: delta method on the logit scale from the fitted parameter covariance.\n", sep = "")
    if (isTRUE(record$restricted_to_interior))
      cat("Conditional on ",
          .gt_conditioning_clause(record$fixed_components, record$fixed_component_kinds),
          "; the intervals carry no uncertainty for those.\n", sep = "")
    else if (length(record$boundary_components))
      cat("No standard error for", .gt_name_sources(record$boundary_components, "boundary_components"),
          "resting on a variance boundary.\n")
  } else if (length(record$reason) && !is.na(record$reason)) {
    cat("No intervals:", record$reason, "\n")
  }
  invisible(NULL)
}

# Print a concise reliability report without expanding fit diagnostics
print.gt_reliability <- function(x, ..., digits = 4L, max_rows = 12L) {
  .gt_print_coefficient_options(digits, max_rows)
  cat("G-theory reliability |", x$scale, "scale\n")
  cat("Facet counts:", paste(paste(names(x$design), x$design, sep = "="), collapse = ", "), "\n")
  if (length(x$fixed_facets))
    cat("Fixed facets:", paste(x$fixed_facets, collapse = ", "), "|", x$model, "\n")
  print(.gt_drop_empty_columns(utils::head(x$per_trait, max_rows)), row.names = FALSE, digits = digits)
  if (nrow(x$per_trait) > max_rows) cat("Further outcomes are available in $per_trait.\n")
  if (!is.null(x$composite)) {
    cat("Weighted composite:\n")
    print(.gt_drop_empty_columns(x$composite), row.names = FALSE, digits = digits)
  }
  cat("Erho2: relative comparisons; Phi: absolute decisions.\n")
  .gt_print_uncertainty_note(x)
  if (identical(x$scale, "latent")) cat("Latent-response coefficients; not observed-score reliability.\n")
  if (isTRUE(x$extrapolated)) cat("Allocation exceeds fitted counts; source covariances are held fixed.\n")
  batch <- .gt_batch_status_text(.gt_batch_status_of(x))
  if (length(batch)) cat(batch, "\n")
  cat("Full covariance matrices and fit diagnostics remain in the returned object.\n")
  invisible(x)
}

# Print allocations and coefficients without expanding fit diagnostics
print.gt_dstudy <- function(x, ..., digits = 4L, max_rows = 12L) {
  .gt_print_coefficient_options(digits, max_rows)
  cat("G-theory decision study |", nrow(x$allocations), "allocations |", x$scale, "scale\n")
  if (length(x$fixed_facets)) cat("Fixed facets:", paste(x$fixed_facets, collapse = ", "), "\n")
  shown <- utils::head(x$results, max_rows)
  allocation <- x$allocations[shown$design_id, , drop = FALSE]
  # Format facets in one column so arbitrary facet names cannot overwrite
  # result columns such as outcome or Phi.
  allocation_text <- vapply(seq_len(nrow(allocation)), function(i)
    paste(paste(names(allocation), unlist(allocation[i, ], use.names = FALSE), sep = "="),
          collapse = ", "), character(1))
  shown <- .gt_drop_empty_columns(shown)
  shown$allocation <- allocation_text
  print(shown, row.names = FALSE, digits = digits)
  if (nrow(x$results) > max_rows)
    cat("Showing", max_rows, "of", nrow(x$results), "rows; see $results and $allocations.\n")
  cat("Erho2: relative comparisons; Phi: absolute decisions. Point projections.\n")
  .gt_print_uncertainty_note(x)
  if (identical(x$scale, "latent")) cat("Latent-response coefficients; not observed-score reliability.\n")
  if (any(x$extrapolated)) cat(sum(x$extrapolated), "allocations exceed fitted counts; source covariances are held fixed.\n")
  batch <- .gt_batch_status_text(.gt_batch_status_of(x))
  if (length(batch)) cat(batch, "\n")
  invisible(x)
}

plot.gt_dstudy <- function(x, coefficient = "Erho2", interval = TRUE, ...,
                           target = NULL, outcome = NULL, kind = NULL) {
  .gt_check_coefficient(coefficient)
  if (!is.logical(interval) || length(interval) != 1L || is.na(interval))
    stop("interval must be TRUE or FALSE.", call. = FALSE)
  if (!is.null(target)) .gt_check_target(target)
  tab <- .gt_reporting_select(as.data.frame(x), outcome, kind)
  keys <- unique(tab[c("kind", "outcome")])
  series <- vapply(seq_len(nrow(tab)), function(i)
    match(TRUE, keys$kind == tab$kind[i] & keys$outcome == tab$outcome[i]), integer(1))
  colors <- seq_len(nrow(keys))
  xx <- tab$measurements_per_object
  lower <- tab[[paste0(coefficient, "_lower")]]
  upper <- tab[[paste0(coefficient, "_upper")]]
  interval_rows <- interval & is.finite(xx) & is.finite(tab[[coefficient]]) &
    is.finite(lower) & is.finite(upper)
  drawn <- any(interval_rows)
  if (!any(is.finite(tab[[coefficient]])))
    stop("No finite coefficient estimates are available to plot.", call. = FALSE)
  values <- c(tab[[coefficient]], if (drawn) c(lower[interval_rows], upper[interval_rows]), target)
  limits <- range(values[is.finite(values)])
  # The graphical settings below are defaults, not fixed arguments. One the
  # caller passes through `...` replaces the matching default instead of being
  # supplied a second time, which is what made plot(study, col = "red") fail
  # with "formal argument matched by multiple actual arguments" (#39).
  dots <- list(...)
  named <- if (is.null(names(dots))) rep(FALSE, length(dots)) else nzchar(names(dots))
  defaults <- list(col = colors[series], pch = ifelse(tab$extrapolated, 1L, 19L),
                   type = "p", ylim = limits,
                   xlab = "Measurements per object",
                   ylab = paste(coefficient, "-", x$scale, "scale"))
  resolved <- utils::modifyList(defaults, dots[named])
  do.call(graphics::plot, c(list(xx, tab[[coefficient]]), resolved, dots[!named]))
  .gt_batch_status_margin(x)
  if (drawn) graphics::segments(xx[interval_rows], lower[interval_rows],
    xx[interval_rows], upper[interval_rows],
    col = rep(resolved$col, length.out = nrow(tab))[interval_rows])
  if (!is.null(target)) graphics::abline(h = target, lty = 2L, col = "grey40")
  legend_rows <- which(!duplicated(data.frame(series = series, extrapolated = tab$extrapolated)))
  labels <- paste0(tab$kind[legend_rows], ": ", tab$outcome[legend_rows],
    ifelse(tab$extrapolated[legend_rows], " (extrapolated)", ""))
  graphics::legend("bottomright", legend = labels,
    col = rep(resolved$col, length.out = nrow(tab))[legend_rows],
    pch = rep(resolved$pch, length.out = nrow(tab))[legend_rows], bty = "n")
  invisible(x)
}
