library(Gtheory4LLM)
# Exercise exported functions from the installed package with a small actual fit.
set.seed(199)
panel <- expand.grid(item = 1:24, rater = 1:4, KEEP.OUT.ATTRS = FALSE)
panel$score <- rep(rnorm(24, sd = 2), 4) + rep(rnorm(4, sd = .5), each = 24) + rnorm(96)
fit <- gt_fit(panel, "score", gt_design("item", "rater"))
stopifnot(isTRUE(fit$numerically_accepted))
previous <- .Random.seed
simulation <- gt_simulate(fit, 16, c(rater = 3), seed = 3)
stopifnot(nrow(simulation) == 48L, identical(previous, .Random.seed))
plan <- gt_pilot_plan(fit, data.frame(n_items = 16), nsim = 1, seed = 3,
  target_counts = c(rater = 2), width_target = .5)
stopifnot(nrow(plan$replicates) == 1L, plan$summary$attempted == 1L,
  is.character(plan$replicates$acceptance_failures), is.character(plan$replicates$selected_attempt),
  is.na(plan$replicates$acceptance_failures), !is.na(plan$replicates$selected_attempt),
  plan$scenario$target_counts[["rater"]] == 2L, identical(previous, .Random.seed))
flat <- as.data.frame(plan)
stopifnot(inherits(plan, "gt_pilot_plan"),
  any(grepl("Pilot precision study", capture.output(print(plan)), fixed = TRUE)),
  identical(names(flat)[1:2], c("design_id", "n_items")),
  identical(flat$attempted, plan$summary$attempted), nrow(flat) == nrow(plan$allocations))
replay_control <- plan$scenario$control
replay_control$gaussian$retry_seed <- plan$replicates$retry_seed
replayed <- gt_fit(gt_simulate(fit, 16, seed = plan$replicates$seed), "score", fit$design,
  estimator = fit$estimator, covariance = fit$covariance_types[fit$design$terms],
  residual = fit$covariance_types[["Residual"]], control = replay_control)
stopifnot(identical(plan$replicates$selected_attempt, gt_diagnostics(replayed)$selected_attempt))
